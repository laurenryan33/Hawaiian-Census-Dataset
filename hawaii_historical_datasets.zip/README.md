# Historical Statistics of Hawaii — visualization-ready CSVs

Source: Robert C. Schmitt, *Historical Statistics of Hawaii* (1977).
https://files.hawaii.gov/dbedt/economic/data_reports/Historical-Statistics-of-Hawaii.pdf

These are selected, manually transcribed tables from the supplied historical source, not a complete extraction of the 716-page book. The scanned pages do not contain an embedded text layer. Verify figures against the original scan before publication.

Files:
- table_12_4_land_division.csv — Table 12.4, printed page in Section 12 (photograph). Historical category subtotals overlap; **do not sum all rows**.
- table_16_6_sugar_exports_1836_1880.csv — Table 16.6, photographed page 418. 1842-1843 is a combined period.
- table_16_6_sugar_production_prices_1881_1902.csv — Table 16.6, photographed page 418. Production in *thousands* of short tons, unlike the export table. The obscured 1888 production figure is blank.
- table_1_14_english_language_1900_1930.csv — Table 1.14, printed p. 29, PDF p. 62.

Blanks represent unavailable or illegible values, never zeros. CSV values contain no thousands separators.

Suggested charts: sugar export growth (line, log-scale optional); sugar production vs raw sugar prices (two separate charts); urban population share over time; English-language measure over time; land division as labeled bars (not a pie because subtotals overlap).

CAUTION: Transcriptions from scans may contain errors. Historical census and racial/ethnic classifications change over time. Source notes and definitions should accompany visualizations.
